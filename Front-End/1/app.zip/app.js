document.getElementById('grey').addEventListener('click', function() {
    console.log("f");
    document.body.style.background = 'grey';
});
document.getElementById('white').addEventListener('click', function() {
    document.body.style.background = 'white';
});
document.getElementById('blue').addEventListener('click', function() {
    document.body.style.background = 'blue';
});
document.getElementById('yellow').addEventListener('click', function() {
    document.body.style.background = 'yellow';
});
